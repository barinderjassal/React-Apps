import React from 'react';

export class AddNewTask extends React.Component {
    constructor(){
        super();
        this.taskSubmitted = this.taskSubmitted.bind(this);
    }

    taskSubmitted (event) {
        event.preventDefault();
        var input = event.target.querySelector('input');
        var value = input.value;
        input.value = "";
        this.props.updateList(value)
    }
    render () {
        return (
            <form onSubmit={this.taskSubmitted}>
                <input type="text" />
            </form>
        );
    }
}
