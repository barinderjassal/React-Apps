
const sum = require('./sum');

// test case 1
test('adds 1 + 2 to equal 3', () => {
    expect(sum(1, 2)).toBe(3);
    // 'toBe' is the Matcher
});

// test case 2
test("concat 'Hello' + ' world' to equal 'Hello world'", () => {
    expect(sum('Hello', ' world')).toBe('Hello world');
});

// test case 3
test('object assignment', () => {
    const data = {
        'one': 1
    };
    data['two'] = 2;
    expect(data).toEqual({'one': 1, 'two': 2});
    // toEqual recursively checks every field of an object or array.
});

// test case 4
test('adding positive number is not zero', () => {
    for (let a = 1; a <= 10; a++) {
        for (let b = 1; b <= 10; b++) {
            expect(sum(a, b)).not.toBe(0);
        }
    }
});

// test case 5 --> Truthies i.e. undefined, null and false
test('null', () => {
    const n = null;
    expect(n).toBeNull();
    expect(n).toBeDefined();
    expect(n).not.toBeUndefined();
    expect(n).not.toBeTruthy();
    expect(n).toBeFalsy();
});

// test case 6 --> Truthies
test('zero', () => {
    const z = 0;
    expect(z).not.toBeNull();
    expect(z).toBeDefined();
    expect(z).not.toBeUndefined();
    expect(z).not.toBeTruthy();
    expect(z).toBeFalsy();
});

// test case 7 --> Numbers (integers)
test('two plus two', () => {
    const value = 2 + 2;
    expect(value).toBeGreaterThan(3);
    expect(value).toBeGreaterThanOrEqual(3.5);
    expect(value).toBeLessThan(5);
    expect(value).toBeLessThanOrEqual(4.5);
  
    // toBe and toEqual are equivalent for numbers
    expect(value).toBe(4);
    expect(value).toEqual(4);
  });

// test case 8 --> Numbers (Floating point)
test('adding floating point numbers', () => {
    const value = 0.1 + 0.2;
    //expect(value).toBe(0.3);           This won't work because of rounding error
    
    expect(value).toBeCloseTo(0.3); // This works.
});

// test case 9 --> Strings
test('there is no I in team', () => {
    expect('team').not.toMatch(/I/);
});

// test case 10 --> Strings against regular expression
test('but there is a "stop" in Christoph', () => {
    expect('Christoph').toMatch(/stop/);
});

// test case 11 --> Arrays
test('shopping list contains beer on it', () => {
    const shoppingList = [
        'biscuits',
        'chocolates',
        'diet coke',
        'whisky',
        'chicken',
        'beer'
    ];
    expect(shoppingList).toContain('beer');
});

// test case 12 --> Promises
/*
test('the data is peanut butter', () => {
    function fetchData () {
        return 'peanut butter';
    }
    expect.assertions(1);
    return fetchData().then(data => {
      expect(data).toBe('peanut butter');
    });
});
*/
// test case 13 --> if Promise is rejected, use catch Method
/*
test('the fetch fails with an error', () => {
    expect.assertions(1);
    return fetchData().catch(e => expect(e).toMatch('error'));
});
*/

// test case 14 --> beforeEach and afterEach

beforeAll(() => console.log('1 - beforeAll'));
afterAll(() => console.log('1 - afterAll'));
beforeEach(() => console.log('1 - beforeEach'));
afterEach(() => console.log('1 - afterEach'));

test('', () => console.log('1 - test'));

describe('Scoped / Nested block', () => {
  beforeAll(() => console.log('describe - beforeAll'));
  afterAll(() => console.log('describe - afterAll'));
  beforeEach(() => console.log('describe - beforeEach'));
  afterEach(() => console.log('describe - afterEach'));
  test('', () => console.log('describe - test'));
});


// test case 15 --> Order of execution of describe and test blocks
/*
describe('outer', () => {
    console.log('describe outer-a');
  
    describe('describe inner 1', () => {
      console.log('describe inner 1');
      test('test 1', () => {
        console.log('test for describe inner 1');
        expect(true).toEqual(true);
      });
    });
  
    console.log('describe outer-b');
  
    test('test 1', () => {
      console.log('test for describe outer');
      expect(true).toEqual(true);
    });
  
    describe('describe inner 2', () => {
      console.log('describe inner 2');
      test('test for describe inner 2', () => {
        console.log('test for describe inner 2');
        expect(false).toEqual(false);
      });
    });
  
    console.log('describe outer-c');
});

*/





