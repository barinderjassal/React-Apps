import React from "react";
import ReactDOM from "react-dom";

import { HelloPlanet } from "./components/HelloPlanetComponent";
// import fetch component
import FetchData from "./components/fetchDataComponent";

/*
 * traditional way of making components
function HelloPlanet (myObject) {
    console.log(myObject)
    return <h1>Hello {myObject.firstName}</h1>
}
 *
 **/

 var myObject = {
     firstName: 'Barinder',
     lastName: 'Singh'
 };

 const element = (
    <div>
        <HelloPlanet name="Earth" num={10} />
        <FetchData />
    </div>
 );

ReactDOM.render(
    // <h1>Hello {HelloPlanet(myObject)}</h1>
    // Any expression written inside div with single curly braces will get evaluated
    element,
    document.getElementById('firstApp')
);