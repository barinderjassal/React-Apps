import { HelloPlanet } from './HelloPlanetComponent';
import React from 'react';
import renderer from 'react-test-renderer';

// counter function check
test.only('updateThisCounter', () => {
    var x = 1;
    var result = HelloPlanet.updateThisCounter(x);
    expect(result).toEqual(2);
});