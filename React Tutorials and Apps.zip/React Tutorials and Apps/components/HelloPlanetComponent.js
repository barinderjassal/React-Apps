import React from "react";

import { PlanetChild } from "./PlanetChildComponent";

export class HelloPlanet extends React.Component {
    constructor (props) {
        super();
        console.log(props);
        this.currentPage = 0
        this.totalPage = 10
        this.state = {
            counter: 0
        }
        // setInterval(()=> {
        //     this.setState({counter: this.state.counter + 1})
        // }, 2000);
        //this.updateThisCounter = this.updateThisCounter.bind(this)
    }
    
    updateThisCounter () {
        this.setState({counter: this.state.counter + 1})
    }

    onPaginationChanged() {
        console.log('page changed');
        this.currentPage++;
        console.log(this.currentPage +' of ' + this.totalPage);
    }

    render () {
        //return <h1>Welcome to {this.props.name}</h1>
        console.log(this.props);
        //return <h1>Welcome to {this.props.name} and person name from object is {this.props.objPass.firstName}</h1>
        //return <h1>My favourite number is {this.state.counter}</h1>
        return <div>
                    <span>{this.state.counter}</span>
                    <br/>
                    <PlanetChild triggerParentUpdateCounter={this.updateThisCounter.bind(this)} />
                </div>
    }
}
//changePageNo={this.onPaginationChanged.bind(this)}

// HelloPlanet.propTypes = {
//     num: React.PropTypes.number
// };

// HelloPlanet.defaultProps = {
//     num: 10
// };
