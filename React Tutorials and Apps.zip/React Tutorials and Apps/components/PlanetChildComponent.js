import React from "react";

// updating data of parent from child component
// here, we are calling parent function

export class PlanetChild extends React.Component {
    constructor (props) {
        super();
    }

    render () {
        
        return <button onClick={this.props.triggerParentUpdateCounter}>Update Counter</button>
        {/* <button onClick={this.props.changePageNo}>Update Page No</button> */}
    
    }
       
}

