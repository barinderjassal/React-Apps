import React from 'react';

const API = 'https://hn.algolia.com/api/v1/search?query=';
const DEFAULT_QUERY = 'react';

class FetchData extends React.Component {
    constructor(props) {
        super(props);
        
        this.state = {
            hits: [],
            isLoading: false,
            error: null
        };
    }

    componentDidMount() {
        this.setState.isLoading = true;
        fetch(API + DEFAULT_QUERY)
        .then(response => {
            if (response.ok) {
                debugger;
                return response.json() ;
            } else {
                throw new Error('Something went wrong...!');
            }
            
        })
        .then(data => this.setState({ hits: data.hits, isLoading: false}))
        .catch(error => this.setState({isLoading: false, error: error}));
    }

    render() {
        var loadingFlag = this.state.isLoading;
        var errorFlag = this.state.error;
        if (errorFlag) {
            return <p>{error.message}</p>;
        }

        if (loadingFlag) {
            return <p>Loading...</p>;
        }
        var hits = this.state.hits.map((hit) => {
            return <li key={hit.objectID}>
                      <a href={hit.url} target="_blank">{hit.title}</a>
                    </li>
        });
        return (
            <div>
                {hits}
            </div>
        )
    }

}
export default FetchData;