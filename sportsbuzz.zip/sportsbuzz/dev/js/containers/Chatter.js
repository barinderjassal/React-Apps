import { connect } from 'react-redux'
import Chatter from '../components/chatter.jsx'
import {postMsg} from '../actions'

let input = "";

const mapStateToProperty = (state) => {
    console.log(state.chatContent)
    return {
        chat :state.chatContent 
    }
} 

const mapDispatchToProperty = dispatch => {
    return {
        sendMessage : (inputField) =>{ 
            if(input){
                let newMsg = {
                    name: "\n" + "Prahlad",
                    msg: input
                }
                dispatch(postMsg(newMsg))
                inputField.value='';
                inputField.focus();
                input='';
            }
        },
        updateMsg : (inputField) => {
            input = inputField.value;
            
        }


    }
}
const chatter = connect(
    mapStateToProperty,
    mapDispatchToProperty
)(Chatter) 

export default chatter