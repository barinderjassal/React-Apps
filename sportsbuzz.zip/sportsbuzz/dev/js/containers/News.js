import { connect } from 'react-redux'
import NewsComponent from '../components/news.jsx'

const mapStateToProps = (state) => {
    return {
        news : state.newsContent.news
    }
}

const mapDispatchToProps = dispatch => {
    return {
        getLatestNews : () => {
            getLatestNews(dispatch)
        }
    }
}
const News = connect(
    mapStateToProps,
    mapDispatchToProps
)(NewsComponent)
export default News