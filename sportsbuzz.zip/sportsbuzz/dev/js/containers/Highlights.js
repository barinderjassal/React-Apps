import { connect } from 'react-redux'
import Carousel from '../components/Carousel'
import {refreshCarousel} from '../actions'
import axios from 'axios';

const getHighlights = (homePage) => {
  return homePage.carousel
}

const fetchHiglights= (dispatch) => {
  console.log("Make the API call");
  
  axios.get('http://localhost:3001/getCarouselData/')
  .then(function(result){
    console.log(result)
    dispatch(refreshCarousel(result)) 
  })
  .catch(function(err){
    console.log(err)
  });
}
const mapStateToProps = (state) => {
  
  console.log("highlights.js" + state.homePage)
  return {
    carousel: getHighlights(state.homePage),
    test: "this is a test"
  }
}

const mapDispatchToProps = dispatch => {
 
  return {
    refreshCarousel: () => { 
      
      fetchHiglights(dispatch)
    }
  }
}

const Highlights = connect(
  mapStateToProps,
  mapDispatchToProps
)(Carousel)

export default Highlights