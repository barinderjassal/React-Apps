import React from 'react';
import Chatter from '../containers/chatter.js';

const News = ({news, getLatestNews}) => (
    <div className='container'>
        <div className = 'row'>
            <div className = 'col-sm-8'>
                <h2 onClick ={()=>getLatestNews()}>News at glance</h2>
                {news.map(temp => (
                    <div key={temp.index}>
                        <h3 className="text-primary">{temp.heading}</h3>
                        <h4>{temp.data}</h4>
                    </div>
                ))}
            </div>

            <div className = 'col-sm-4'>
                <Chatter> </Chatter>
            </div>
        </div>
    </div>
)

export default News;