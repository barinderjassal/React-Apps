import React from 'react';

import Navbar from 'react-bootstrap/lib/Navbar';
import Nav from 'react-bootstrap/lib/Nav';
import NavItem from 'react-bootstrap/lib/NavItem';
import { BrowserRouter, Route, Switch, Link} from 'react-router-dom';
/*import NavDropdown from 'react-bootstrap/lib/NavDropdown';
import MenuItem from 'react-bootstrap/lib/MenuItem';
import NavItem from 'react-bootstrap/lib/NavItem';
import LinkContainer from 'react-router-bootstrap/lib/LinkContainer';*/

import Gamelinks from './Gamelinks.jsx';
import Cricket from './Cricket.js';

const Navigation = () => (
    <BrowserRouter>
        <div>
            <Navbar inverse fluid>
                <Nav>
                    <NavItem active><span className="glyphicon glyphicon-home"></span>
                        <Link to={'/'} >Home</Link>
                    </NavItem>
                    <NavItem><Link to={'/Cricket'} >Cricket</Link></NavItem>
                    <NavItem><Link to={'/Football'} >Football</Link></NavItem>
                    <NavItem><Link to={'/Hockey'} >Hockey</Link></NavItem>
                </Nav>
                <Nav pullRight>
                    <NavItem>
                        <span className="glyphicon glyphicon-user">
                            <span className="caret" data-toggle="dropdown"></span>
                        </span>
                        <ul className="dropdown-menu">
                            <li><a href="#">My Account</a></li>
                            <li><a href="#">Logout!</a></li>
                        </ul>
                    </NavItem>
                </Nav>
            </Navbar >
            <hr />

            <div>
                <h2>Welcome to Sports Buzz</h2>
                <Cricket />
                <Switch>
                    {/* <Route exact path="/" component={Cricket} /> */}
                    {/* <Route path='/Cricket' component={Cricket} /> */}
                    {/* <Route path='/AwesomeComponent' component={AwesomeComponent} />
                    <Route path='/Contact' component={Contact} />
                    <Route path='*' component={NotFound} /> */}
                </Switch>
            </div>
            
        </div>
    </BrowserRouter>
)

export default Navigation;
