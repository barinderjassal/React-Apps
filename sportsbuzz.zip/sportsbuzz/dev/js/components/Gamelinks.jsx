import React from 'react';
import { Link } from 'react-router-dom';

class Gamelinks extends React.Component {
    render() {
        return(
           <div>
                <ul>
                    <li><Link to={'/'}>Home</Link></li>
                    <li><Link to={'/Cricket'}>Cricket</Link></li>
                    <li><Link to={'/Football'}>Football</Link></li>
                    <li><Link to={'/Hockey'}>Hockey</Link></li>
                </ul>
            </div>

        );
    }
}

export default Gamelinks;

