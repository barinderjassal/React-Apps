import React from 'react';

const Chatter = ({chat, sendMessage, inputField, updateMsg}) => (
    
    <div className='container'>
        <div className="form-group">
            <div className='row'>
                <textarea rows="15" cols="100" value={chat.map((a)=>a.name + " : "+ a.msg )}></textarea>
            </div>
            <div className='row'>
            <textarea rows="4" cols="100" ref={node=> {inputField=node}} onChange={()=>updateMsg(inputField)}></textarea>
            </div>
            <div className='row'>
                <input  className = 'left' type='button' value="Send" onClick={() => sendMessage(inputField)}></input>
            </div>
        </div>
    </div>
)
export default Chatter