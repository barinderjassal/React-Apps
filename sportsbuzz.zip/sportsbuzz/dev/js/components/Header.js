import React from 'react';
import Input from 'react-bootstrap/lib/InputGroupAddon';

const Header = () => (
    <div className="container">
        <div className="row">
            <div className="col-sm-4">
                {/*<img src="../../img/logo.png"></img>*/}
            </div>
            <div className="col-sm-8">
                <form className="navbar-form navbar-left" action="#">
                    <div className="input-group">
                        <input type="text" className="form-control input-lg" placeholder="Search" name="search"></input>
                        <div className="input-group-btn">
                            <button className="btn btn-default btn-lg" type="submit">
                                <i className="glyphicon glyphicon-search"></i>
                            </button>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>
)


export default Header