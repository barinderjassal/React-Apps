import React from 'react';
import { Provider } from 'react-redux';
import Navigation from './Nav.js';
import Header from './Header.js';
import Highlight from '../containers/Highlights.js';
import News from '../containers/News.js';
require('../../scss/style.scss');

const App = ({ store }) => (
  <Provider store={store}>
    <div>
      <Navigation />
      {/* <Header />
      <Highlight />
      <News /> */}
    </div>
  </Provider>
)

export default App