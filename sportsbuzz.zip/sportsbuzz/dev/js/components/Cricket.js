import React from 'react';


import Highlight from '../containers/Highlights.js';
import News from '../containers/News.js';

// import Highlights from '../containers/Highlights.js';

// class Cricket extends React.Component {
//     render () {
//       return(
//           <div>
//               <Carousel />
//               <News />
//           </div>
//       );
//     }
// }

const Cricket = () => (
    <div className="container">
        <Highlight />
        <News />

    </div>
)


export default Cricket;