export const refreshCarousel = (request) => {
  return {
    type: 'REFRESH_CAROUSEL',
    payload: request
  }
}
export const fetchNews = (request) => {
  return {
    type: 'FETCH_NEWS',
    payload: request
  }
}
export const postMsg = (msg) => {
  return {
    type:'POST_MSG',
    payload:msg
  }
}