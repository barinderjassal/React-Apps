import { combineReducers } from 'redux'
import homePage from './homePage'
import newsContent from './newsContent'
import chatContent from './chatContent'

const sportsInfo = combineReducers({
  homePage,
  newsContent,
  chatContent
})

export default sportsInfo;