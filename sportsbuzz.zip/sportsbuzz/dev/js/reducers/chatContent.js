const initialChat = []
const chatContent = (chat=initialChat, action) => {
    switch (action.type){
        case 'POST_MSG':
        return [
            ...chat, {
                name:action.payload.name,
                msg:action.payload.msg
            }
        ]
        default :{
            return chat
        }
    }
}

export default chatContent