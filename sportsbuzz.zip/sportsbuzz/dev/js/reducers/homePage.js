

const homePage = (mainPage = [], action) => {
  switch (action.type) {
    case 'REFRESH_CAROUSEL':
    console.log("---------------------" + action.payload.data);
      return {
        // Get data from API
        "carousel" : action.payload.data
      }
    default:
      return {
        "carousel": [{
          index:1,
          "caption":"First Carousel",
          "img":"highlight1.jpg",
          "active" : "active"
        }, {
          index:2,
          "caption":"Second Carousel",
          "img":"highlight2.jpg"
        }, {
          index:3,
          "caption":"Third Carousel",
          "img":"highlight3.jpg"
        }]
      }
  }
}

export default homePage
