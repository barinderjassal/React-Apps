const newsContent = (news = [], action) => {
  switch (action.type){
      case 'FETCH_NEWS' :
        console.log("Fetch Latest news")
        return {
            "news" : [
                {
                    img : '',
                    data : ''
                },
                {
                    img : '',
                    data : ''
                }
            ]
        }
      default :
        return {
            "news" : [
                {
                    index: 1,
                    img : 'news1',
                    heading :'Indian beats South Africa by 89 runs',
                    data : 'Indian team beats south africe in second one-day international. South Africe was all out at 139 while chasing the score of 228. Rabinder jadega bowled the magical spell of 2-1-5-4 and was named as man of the match'
                },
                {
                    index: 2,
                    img : 'news2',
                    heading :'Sachin tendulkar gifts his Ferrari',
                    data : 'Saniya mahiwal now joins the ferrari group, as Sachin tendulkar gifts his Red ferrari for her outstanding performance oversees. He says, she has made our country proud and wishes her all the best in her career.'
                }
            ]
        }
  }
}
export default newsContent