import React, { Component } from 'react';
import { createStore } from 'redux';

class ReduxDemo extends Component {
    render() {

        // step 2 Reducer: state and action
        const reducer = function (state, action) {
            if (action.type === 'ATTACK') {
                return action.payload;
            }
            if (action.type === 'DEFEND') {
                return action.payload;
            }
            return console.log(state);
        }

        // step 1 Store: reducer and state (only one store in whole application)
        const store = createStore(reducer, 'peace'); // 'peace' is an initial state 

        // step 3 subscribe
        store.subscribe(() => {
            console.log('store is now', store.getState());
        });

        // step 4 dispatch action
        store.dispatch({type: 'ATTACK', payload: 'Send Enemies'});
        store.dispatch({type: 'DEFEND', payload: 'Call Avengers'});


        return (
            <div>
                Hello World!!
            </div>
        );
    }
}
export default ReduxDemo;
